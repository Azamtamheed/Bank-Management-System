import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;
import java.util.Date;//for date class

public class FastCash extends JFrame implements ActionListener {
    JButton option1,option2,option3,option4,option5,option6,back;//global declaration
    String pinnumber;
    FastCash(String pinnumber){
        this.pinnumber=pinnumber;//storing global var in local
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/atm.jpg"));
        Image i2 = i1.getImage().getScaledInstance(900,900,Image.SCALE_DEFAULT);
        ImageIcon i3= new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0,0,900,900);
        add (image);
        JLabel text = new JLabel("SELECT WITHDRAWL AMOUNT");
        text.setBounds(210,300,700,35);
        text.setForeground(Color.WHITE);
        text.setFont(new Font("System",Font.BOLD,16));
        image.add(text);//text over image

        option1= new JButton("RM 100");
        option1.setBounds(170,415,150,30);
        option1.addActionListener(this);
        image.add(option1);

        option2= new JButton("RM 200");
        option2.setBounds(355,415,150,30);
        option2.addActionListener(this);
        image.add(option2);

        option3= new JButton("RM 300");
        option3.setBounds(170,450,150,30);
        option3.addActionListener(this);
        image.add(option3);

        option4= new JButton("RM 500");
        option4.setBounds(170,485,150,30);
        option4.addActionListener(this);
        image.add(option4);

        option5= new JButton("RM 700");
        option5.setBounds(355,450,150,30);
        option5.addActionListener(this);
        image.add(option5);

        option6= new JButton("RM900");
        option6.setBounds(355,485,150,30);
        option6.addActionListener(this);
        image.add(option6);

        back= new JButton("BACK");
        back.setBounds(355,520,150,30);
        back.addActionListener(this);
        image.add(back);


        setSize(900,900);
        setLocation(300,0);
        setUndecorated(true);//to remove the top white
        setVisible(true);//put at the end

    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==back){
            setVisible(false);//hide fastcash page
            new Transactions(pinnumber).setVisible(true);//sjow transaction page

        }else{
            String amount= ((JButton)ae.getSource()).getText().substring(3);// will get the text on button eg RM 100 using substring three to minus 3 char RM and space
            conn c=new conn();
            try{
                ResultSet rs = c.s.executeQuery("select * from bank where pin='"+pinnumber+"'");//check if they have balance for withdraw fas cash
                int balance=0;//set bal to 0 rs next to loop each row
                while(rs.next()){
                    if(rs.getString("type").equals("Deposit")){
                        balance +=Integer.parseInt(rs.getString("amount"));//converting string to int adding dep to bal
                    }else{
                        balance-=Integer.parseInt(rs.getString("amount"));//converting string to int sub withraw to bal
                    }

                }
                // bal  or less than balance
                if(ae.getSource()!=back && balance<Integer.parseInt(amount)){
                    JOptionPane.showMessageDialog(null,"Insufficiet Balance");
                    return;//so that user can do any transaction of withdrawal

                }
                Date date = new Date();
                String query ="insert into bank value ('"+pinnumber+"','"+date+"','Withdrawl','"+amount+"')";
                c.s.executeUpdate(query);
                JOptionPane.showMessageDialog(null,"RM "+amount+" Debited Sucessfully");//after debit pop message
                setVisible(false);//hide current frame
                new Transactions(pinnumber).setVisible(true);//show trans page
            }catch(Exception e){
                System.out.println(e);
            }
        }

    }
    public static void main(String args[]){
        new FastCash("");
    }

}