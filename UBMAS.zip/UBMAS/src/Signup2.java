


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.sql.*;

public class Signup2 extends JFrame implements ActionListener{

    JLabel titleLabel,religionLabel,raceLabel,incomeLabel,eduLabel,
            occupationLabel,metricNumLabel,passportLabel,internationalStudent,eaLabel,
            formLabel,formNumLabel, othersLabel;
    JButton nextButton;
    JRadioButton scYesRadio,scNoRadio,eaYesRadio,eaNoRadio, ownBusRadio, employedRadio, othersRadio;
    JTextField metricTextField,passportTextField, othersOccuTextField, othersTextField;
    JComboBox religionDrop,raceDrop,incomeDrop,eduDrop; //Dropdown list
    String formNumber;
    Signup2(String formNumber){

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("ASimulatorSystem/icons/logo.jpg"));
        Image i2 = i1.getImage().getScaledInstance(95, 61, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel icon = new JLabel(i3);
        icon.setBounds(20, 20, 95, 61);
        add(icon);


        this.formNumber = formNumber;
        setTitle("NEW ACCOUNT APPLICATION FORM - PAGE 2");

        titleLabel = new JLabel("Page 2: Additonal Details");
        titleLabel.setFont(new Font("Raleway", Font.BOLD, 22));

        religionLabel = new JLabel("Religion:");
        religionLabel.setFont(new Font("Raleway", Font.BOLD, 18));

        raceLabel = new JLabel("Race:");
        raceLabel.setFont(new Font("Raleway", Font.BOLD, 18));

        incomeLabel = new JLabel("Current Annual Income:");
        incomeLabel.setFont(new Font("Raleway", Font.BOLD, 16));

        eduLabel = new JLabel("<html>Educational<br>Level</html>");
        eduLabel.setFont(new Font("Raleway", Font.BOLD, 18));

        occupationLabel = new JLabel("Employment / Business:");
        occupationLabel.setFont(new Font("Raleway", Font.BOLD, 16));

        metricNumLabel = new JLabel("Metric Number:");
        metricNumLabel.setFont(new Font("Raleway", Font.BOLD, 18));

        passportLabel = new JLabel("Passport Number:");
        passportLabel.setFont(new Font("Raleway", Font.BOLD, 18));

        internationalStudent = new JLabel("International Student:");
        internationalStudent.setFont(new Font("Raleway", Font.BOLD, 18));

        eaLabel = new JLabel("Existing Account:");
        eaLabel.setFont(new Font("Raleway", Font.BOLD, 18));

        formLabel = new JLabel("Form No:");
        formLabel.setFont(new Font("Raleway", Font.BOLD, 13));

        formNumLabel = new JLabel(formNumber);
        formNumLabel.setFont(new Font("Raleway", Font.BOLD, 13));

        othersLabel = new JLabel("Others, please specify");
        othersLabel.setFont(new Font("Raleway", Font.BOLD, 12));

        othersTextField = new JTextField();
        othersTextField.setFont(new Font("Raleway", Font.BOLD, 14));

        nextButton = new JButton("Next");
        nextButton.setFont(new Font("Raleway", Font.BOLD, 14));
        nextButton.setBackground(Color.BLACK);
        nextButton.setForeground(Color.WHITE);

        metricTextField = new JTextField();
        metricTextField.setFont(new Font("Raleway", Font.BOLD, 14));

        passportTextField = new JTextField();
        passportTextField.setFont(new Font("Raleway", Font.BOLD, 14));

        scYesRadio = new JRadioButton("Yes");
        scYesRadio.setFont(new Font("Raleway", Font.BOLD, 14));
        scYesRadio.setBackground(Color.WHITE);

        scNoRadio = new JRadioButton("No");
        scNoRadio.setFont(new Font("Raleway", Font.BOLD, 14));
        scNoRadio.setBackground(Color.WHITE);

        ButtonGroup seniorCitizenGroup = new ButtonGroup();
        seniorCitizenGroup.add(scYesRadio);
        seniorCitizenGroup.add(scNoRadio);

        eaYesRadio = new JRadioButton("Yes");
        eaYesRadio.setFont(new Font("Raleway", Font.BOLD, 14));
        eaYesRadio.setBackground(Color.WHITE);

        eaNoRadio = new JRadioButton("No");
        eaNoRadio.setFont(new Font("Raleway", Font.BOLD, 14));
        eaNoRadio.setBackground(Color.WHITE);

        ButtonGroup existingAccountGroup = new ButtonGroup();
        existingAccountGroup.add(eaYesRadio);
        existingAccountGroup.add(eaNoRadio);

        ownBusRadio = new JRadioButton("Own Business");
        ownBusRadio.setFont(new Font("Raleway", Font.BOLD, 12));
        ownBusRadio.setBackground(Color.WHITE);

        employedRadio = new JRadioButton("Employed (Contract / Permanent)");
        employedRadio.setFont(new Font("Raleway", Font.BOLD, 12));
        employedRadio.setBackground(Color.WHITE);

        othersRadio = new JRadioButton("Others, please specify");
        othersRadio.setFont(new Font("Raleway", Font.BOLD, 12));
        othersRadio.setBackground(Color.WHITE);

        othersOccuTextField = new JTextField();
        othersOccuTextField.setFont(new Font("Raleway", Font.BOLD, 14));

        ButtonGroup occupationTypeGroup = new ButtonGroup();
        occupationTypeGroup.add(ownBusRadio);
        occupationTypeGroup.add(employedRadio);
        occupationTypeGroup.add(othersRadio);

        String religion[] = {"Muslim","Buddhist","Christian","Hindu","Jewish", "Other"};
        religionDrop = new JComboBox(religion);
        religionDrop.setBackground(Color.WHITE);
        religionDrop.setFont(new Font("Raleway", Font.BOLD, 14));

        String race[] = {"Malay","Chinese","Indian", "Others"};
        raceDrop = new JComboBox(race);
        raceDrop.setBackground(Color.WHITE);
        raceDrop.setFont(new Font("Raleway", Font.BOLD, 14));

        String income[] = {"Null","RM20,000 and below","RM20,001 - RM40,000","RM40,001 - RM60,000",
                "RM60,001 - RM100,000","RM100,001 - RM250,000", "RM250,001 - RM500,000", "RM500,001 - RM1,000,000",
                "Above RM1,000,000"};
        incomeDrop = new JComboBox(income);
        incomeDrop.setBackground(Color.WHITE);
        incomeDrop.setFont(new Font("Raleway", Font.BOLD, 14));

        String education[] = {"Primary","Secondary","Diploma","Degree","Masters", "Doctorate", "Professional Qualification"};
        eduDrop = new JComboBox(education);
        eduDrop.setBackground(Color.WHITE);
        eduDrop.setFont(new Font("Raleway", Font.BOLD, 14));

        setLayout(null);

        formLabel.setBounds(700,10,60,30);
        add(formLabel);

        formNumLabel.setBounds(760,10,60,30);
        add(formNumLabel);

        othersLabel.setBounds(450,170,130,30);
        add(othersLabel);

        othersTextField.setBounds(585,170,85,30);
        add(othersTextField);

        titleLabel.setBounds(280,30,600,40);
        add(titleLabel);

        religionLabel.setBounds(100,120,100,30);
        add(religionLabel);

        religionDrop.setBounds(350,120,320,30);
        add(religionDrop);

        raceLabel.setBounds(100,170,100,30);
        add(raceLabel);

        raceDrop.setBounds(350,170,90,30);
        add(raceDrop);

        incomeLabel.setBounds(100,220,180,30);
        add(incomeLabel);

        incomeDrop.setBounds(350,220,320,30);
        add(incomeDrop);

        ownBusRadio.setBounds(350,310,125,30);
        add(ownBusRadio);

        employedRadio.setBounds(480,310,220,30);
        add(employedRadio);

        othersRadio.setBounds(350,350,160,30);
        add(othersRadio);

        othersOccuTextField.setBounds(510,350,160,30);
        add(othersOccuTextField);

        eduLabel.setBounds(100,270,150,40);
        add(eduLabel);

        eduDrop.setBounds(350,270,320,30);
        add(eduDrop);

        occupationLabel.setBounds(100,340,200,30);
        add(occupationLabel);

        metricNumLabel.setBounds(100,390,150,30);
        add(metricNumLabel);

        metricTextField.setBounds(350,390,320,30);
        add(metricTextField);

        passportLabel.setBounds(100,440,180,30);
        add(passportLabel);

        passportTextField.setBounds(350,440,320,30);
        add(passportTextField);

        internationalStudent.setBounds(100,490,200,30);
        add(internationalStudent);

        scYesRadio.setBounds(350,490,100,30);
        add(scYesRadio);

        scNoRadio.setBounds(460,490,100,30);
        add(scNoRadio);

        eaLabel.setBounds(100,540,180,30);
        add(eaLabel);

        eaYesRadio.setBounds(350,540,100,30);
        add(eaYesRadio);

        eaNoRadio.setBounds(460,540,100,30);
        add(eaNoRadio);

        nextButton.setBounds(570,640,100,30);
        add(nextButton);

        nextButton.addActionListener(this);

        getContentPane().setBackground(Color.WHITE);

        setSize(850,750);
        setLocation(500,120);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae){
        String selectedRace = (String)raceDrop.getSelectedItem();
        String race;
        // Validate if "Others" is selected
        if ("Others".equals(selectedRace)) {
            System.out.println("Selected race is Others");
            race = othersTextField.getText();
            System.out.println(race);
        } else {
            race = (String)raceDrop.getSelectedItem();
            System.out.println(race);
        }
        String religion = (String)religionDrop.getSelectedItem();
        String income = (String)incomeDrop.getSelectedItem();
        String education = (String)eduDrop.getSelectedItem();
        String metricNum = metricTextField.getText();
        String PassportNum = passportTextField.getText();

        String occupation = "";
        if(ownBusRadio.isSelected()) {
            occupation = "Own Business";
        } else if(employedRadio.isSelected()) {
            occupation = "Employed";
        } else if(othersRadio.isSelected()){
            String inputText = othersOccuTextField.getText();
            // Check if the text is empty
            if (inputText.isEmpty()) {
                // Show an error message or take appropriate action
                JOptionPane.showMessageDialog(null, "Please enter a value in the 'Others' text field", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                // The text field has a value, you can proceed with further actions
                System.out.println("Entered value: " + inputText);
                occupation = othersOccuTextField.getText();
            }

        }

        String internationalStudent = "";
        if(scYesRadio.isSelected()){
            internationalStudent = "Yes";
        }
        else if(scNoRadio.isSelected()){
            internationalStudent = "No";
        }

        String eaccount = "";
        if(eaYesRadio.isSelected()){
            eaccount = "Yes";
        }else if(eaNoRadio.isSelected()){
            eaccount = "No";
        }

        try{
            if(passportTextField.getText().equals("")){
                JOptionPane.showMessageDialog(null, "Fill all the required fields");
            }else{
                conn c2 = new conn();
                String q1 = "insert into signup2 values('"+formNumber+"','"+religion+"','"+race+"','"+income+"','"+education+"','"+occupation+"','"+metricNum+"','"+PassportNum+"','"+internationalStudent+"','"+eaccount+"')";
                c2.s.executeUpdate(q1);

                new signupthree(formNumber).setVisible(true);
                setVisible(false);
            }



        } catch(Exception ex){
            ex.printStackTrace();
        }


    }


    public static void main(String[] args){
        new Signup2("").setVisible(true);
    }
}

