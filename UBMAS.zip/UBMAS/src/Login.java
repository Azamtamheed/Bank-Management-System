import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;



public class Login extends JFrame implements ActionListener {
    JButton log,sign,clear;
    JTextField cardTextField;
    JPasswordField pinTextField;
    Login(){
        setTitle("AUTOMATED TELLER MACHINE");
        setLayout(null);
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/usm.jpg"));
        Image i2=i1.getImage().getScaledInstance(100,100, Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel label=new JLabel(i3);
        label.setBounds(70,10,100,100);
        add(label);
        JLabel text=new JLabel("Welcome to ATM");
        text.setFont(new Font("Osward", Font.BOLD,38));
        text.setBounds(200,40,400,40);
        add(text);

        JLabel card=new JLabel("Card No: ");
        card.setFont(new Font("Raleway", Font.BOLD,28));
        card.setBounds(120,150,250,30);
        add(card);

        cardTextField=new JTextField();
        cardTextField.setBounds(300,150,230,30);
        cardTextField.setFont(new Font("Arial", Font.BOLD, 14));
        add(cardTextField);

        JLabel pin=new JLabel("PIN: ");
        pin.setFont(new Font("Raleway", Font.BOLD,28));
        pin.setBounds(120,220,250,30);
        add(pin);

        pinTextField=new JPasswordField();
        pinTextField.setBounds(300,220,230,30);
        pinTextField.setFont(new Font("Arial", Font.BOLD, 14));
        add(pinTextField);

        log=new JButton("SIGN IN");
        log.setBounds(300,300,100,30);
        log.setBackground(Color.white);
        log.setForeground(Color.black);
        log.addActionListener(this);
        add(log);

        clear=new JButton("CLEAR");
        clear.setBounds(430,300,100,30);
        clear.setBackground(Color.white);
        clear.setForeground(Color.black);
        clear.addActionListener(this);
        add(clear);

        sign=new JButton("SIGN UP");
        sign.setBounds(300,350,230,30);
        sign.setBackground(Color.white);
        sign.setForeground(Color.black);
        sign.addActionListener(this);
        add(sign);






        getContentPane().setBackground(Color.WHITE);
        setSize(800,480);
        setVisible(true);
        setLocation(300,200);

    }
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()==clear){
            cardTextField.setText("");
            pinTextField.setText("");
        }
        else if(ae.getSource()==log){
            conn conn = new conn();//to establish connection to database
            String cardNumber = cardTextField.getText();//to gt card
            String pinnumber = pinTextField.getText();//to get pin
            String query="select * from login where cardnumber='"+cardNumber+"'and pin='"+pinnumber+"'";//query to get data with maches where
            try{//for error
                ResultSet rs=conn.s.executeQuery(query);// to execute the query.... if rsset has data user has loged in sucessful
                if(rs.next()){//to check data
                    setVisible(false);//to close login frame
                    new Transactions(pinnumber).setVisible(true);//to open transaction page also frowarding pn in transaction class in ()
                }else{
                    JOptionPane.showMessageDialog(null,"Incorrect Card Number or Pin");//to pop when wrong detail
                }
            }catch(Exception e){
                System.out.println(e);
            }

        } else if (ae.getSource()==sign) {
            setVisible(false);
            new signupone().setVisible(true);
        }

    }

    public static void main(String a[]) {
        new Login();
    }
}