import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import javax.swing.*;
import java.util.*;

class BalanceEnquiry extends JFrame implements ActionListener {
    JButton back;
    String pinnumber;
    BalanceEnquiry(String pinnumber){
        this.pinnumber=pinnumber;
        setLayout(null);
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/atm.jpg"));
        Image i2 = i1.getImage().getScaledInstance(900,900,Image.SCALE_DEFAULT);
        ImageIcon i3= new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0,0,900,900);
        add (image);

        back = new JButton("BACK");
        back.setBounds(355,520,150,30);
        back.addActionListener(this);
        image.add(back);
        int balance=0;//set bal to 0 rs next to loop each row
        conn c= new conn();
        try{

            ResultSet rs = c.s.executeQuery("select * from bank where pin='"+pinnumber+"'");//check if they have balance for withdraw fas cash

            while(rs.next()){
                if(rs.getString("type").equals("Deposit")){
                    balance +=Integer.parseInt(rs.getString("amount"));//converting string to int adding dep to bal
                }else{
                    balance-=Integer.parseInt(rs.getString("amount"));//converting string to int sub withraw to bal
                }

            }
        }catch(Exception e){
            System.out.println(e);
        }



        JLabel text = new JLabel("Your Current Account Balance Is RM "+balance);
        text.setBounds(170,300,400,30);
        text.setForeground(Color.WHITE);
        text.setFont(new Font("System",Font.BOLD,16));
        image.add(text);//text over image


        setSize(900,900);
        setLocation(300,0);
        setUndecorated(true);//to remove the top white
        setVisible(true);//put at the end
    }



    public void actionPerformed(ActionEvent ae) {
        setVisible(false);
        new Transactions(pinnumber).setVisible(true);
    }


    public static void main(String[] args) {
        new BalanceEnquiry("").setVisible(true);
    }

}