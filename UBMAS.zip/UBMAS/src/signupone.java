import javax.swing.*;
import java.awt.*;
import java.util.*;
import com.toedter.calendar.JDateChooser;
import java.awt.event.*;

public class signupone extends JFrame implements ActionListener{
    long random;
    JTextField nameTextField,fnameTextField,emailTextField,addTextField,cityTextField,stateTextField,pinTextField;
    JButton next;
    JRadioButton male,female,other,married,single,divorced;
    JDateChooser date;

    signupone(){
        setLayout(null);
        Random ran=new Random();
        random=Math.abs(ran.nextLong()%9000L)+1000L;
        JLabel form=new JLabel("APPLICATION FORM NO. "+random);
        form.setFont(new Font("Raleway", Font.BOLD,38));
        form.setBounds(140,20,600,40);
        add(form);

        JLabel personal=new JLabel(" Page 1: Personal Details");
        personal.setFont(new Font("Raleway", Font.BOLD,22));
        personal.setBounds(290,80,400,30);
        add(personal);

        JLabel name=new JLabel("Name:");
        name.setFont(new Font("Raleway", Font.BOLD,20));
        name.setBounds(100,140,100,30);
        add(name);

        nameTextField=new JTextField();
        nameTextField.setFont(new Font("Raleway",Font.BOLD,14));
        nameTextField.setBounds(300,140,400,30);
        add(nameTextField);

        JLabel fname=new JLabel("Father's Name:");
        fname.setFont(new Font("Raleway", Font.BOLD,20));
        fname.setBounds(100,190,200,30);
        add(fname);

        fnameTextField=new JTextField();
        fnameTextField.setFont(new Font("Raleway",Font.BOLD,14));
        fnameTextField.setBounds(300,190,400,30);
        add(fnameTextField);

        JLabel dob=new JLabel("Date of Birth:");
        dob.setFont(new Font("Raleway", Font.BOLD,20));
        dob.setBounds(100,240,200,30);
        add(dob);

        date=new JDateChooser();
        date.setBounds(300,240,400,30);
        date.setForeground(Color.BLACK);
        add(date);


        JLabel gender=new JLabel("Gender:");
        gender.setFont(new Font("Raleway", Font.BOLD,20));
        gender.setBounds(100,290,200,30);
        add(gender);

        male=new JRadioButton("Male");
        male.setBounds(300,290,120,30);
        male.setBackground(Color.WHITE);
        add(male);

        female=new JRadioButton("Female");
        female.setBounds(450,290,120,30);
        female.setBackground(Color.WHITE);
        add(female);

        other=new JRadioButton("Other");
        other.setBounds(600,290,120,30);
        other.setBackground(Color.WHITE);
        add(other);

        ButtonGroup gendergroup= new ButtonGroup();
        gendergroup.add(male);
        gendergroup.add(female);
        gendergroup.add(other);


        JLabel email=new JLabel("Email Address:");
        email.setFont(new Font("Raleway", Font.BOLD,20));
        email.setBounds(100,340,200,30);
        add(email);

        emailTextField=new JTextField();
        emailTextField.setFont(new Font("Raleway",Font.BOLD,14));
        emailTextField.setBounds(300,340,400,30);
        add(emailTextField);

        JLabel marital=new JLabel("Marital Status:");
        marital.setFont(new Font("Raleway", Font.BOLD,20));
        marital.setBounds(100,390,200,30);
        add(marital);

        single=new JRadioButton("Single");
        single.setBounds(300,390,120,30);
        single.setBackground(Color.WHITE);
        add(single);

        married=new JRadioButton("Married");
        married.setBounds(450,390,120,30);
        married.setBackground(Color.WHITE);
        add(married);

        divorced=new JRadioButton("Divorced");
        divorced.setBounds(600,390,120,30);
        divorced.setBackground(Color.WHITE);
        add(divorced);

        ButtonGroup maritalgroup=new ButtonGroup();
        maritalgroup.add(single);
        maritalgroup.add(married);
        maritalgroup.add(divorced);



        JLabel address=new JLabel("Address:");
        address.setFont(new Font("Raleway", Font.BOLD,20));
        address.setBounds(100,440,200,30);
        add(address);

        addTextField=new JTextField();
        addTextField.setFont(new Font("Raleway",Font.BOLD,14));
        addTextField.setBounds(300,440,400,30);
        add(addTextField);

        JLabel city=new JLabel("City:");
        city.setFont(new Font("Raleway", Font.BOLD,20));
        city.setBounds(100,490,200,30);
        add(city);

        cityTextField=new JTextField();
        cityTextField.setFont(new Font("Raleway",Font.BOLD,14));
        cityTextField.setBounds(300,490,400,30);
        add(cityTextField);

        JLabel state=new JLabel("State:");
        state.setFont(new Font("Raleway", Font.BOLD,20));
        state.setBounds(100,540,200,30);
        add(state);

        stateTextField=new JTextField();
        stateTextField.setFont(new Font("Raleway",Font.BOLD,14));
        stateTextField.setBounds(300,540,400,30);
        add(stateTextField);


        JLabel code=new JLabel("Pin Code:");
        code.setFont(new Font("Raleway", Font.BOLD,20));
        code.setBounds(100,590,200,30);
        add(code);

        pinTextField=new JTextField();
        pinTextField.setFont(new Font("Raleway",Font.BOLD,14));
        pinTextField.setBounds(300,590,400,30);
        add(pinTextField);


        next=new JButton("Next");
        next.setBackground(Color.WHITE);
        next.setForeground(Color.BLACK);

        next.setBounds(620,660,80,30);
        next.addActionListener(this);
        add(next);


        getContentPane().setBackground(Color.white);

        setSize(850,800);
        setLocation(350,10);
        setVisible(true);
    }




    public void actionPerformed(ActionEvent e) {
        String form=""+random;//long
        String name=nameTextField.getText();//setText
        String fname=fnameTextField.getText();
        String dob=((JTextField) date.getDateEditor().getUiComponent()).getText();
        String gender=null;
        if(male.isSelected()){
            gender="Male";
        }
        else if (female.isSelected()) {
            gender="Female";
        } else if (other.isSelected()) {
            gender="Other";
        }
        String email=emailTextField.getText();
        String marital=null;
        if(single.isSelected()){
            marital="Single";
        }
        else if(married.isSelected()){
            marital="Married";
        }
        else if(divorced.isSelected()){
            marital="Divorced";
        }
        String add=addTextField.getText();
        String city=cityTextField.getText();
        String state=stateTextField.getText();
        String pin=pinTextField.getText();


        try{
            if(name.equals("")){
                JOptionPane.showMessageDialog(null,"Name field cannot be empty");
            }
            else if(fname.equals("")){
                JOptionPane.showMessageDialog(null,"Father's Name field cannot be empty");
            }
            else if(dob.equals("")){
                JOptionPane.showMessageDialog(null,"Date of Birth field cannot be empty");
            }
            else if(gender.equals("")){
                JOptionPane.showMessageDialog(null,"Gender field cannot be empty");
            }

            else if(email.equals("")){
                JOptionPane.showMessageDialog(null,"Email field cannot be empty");
            }
            else if(marital.equals("")){
                JOptionPane.showMessageDialog(null,"Marital Status field cannot be empty");
            }
            else if(add.equals("")){
                JOptionPane.showMessageDialog(null,"Address field cannot be empty");
            }
            else if(city.equals("")){
                JOptionPane.showMessageDialog(null,"CIty field cannot be empty");
            }
            else if(state.equals("")){
                JOptionPane.showMessageDialog(null,"State field cannot be empty");
            }
            else if(pin.equals("")){
                JOptionPane.showMessageDialog(null,"Pin Code field cannot be empty");
            }else {
                conn c=new conn();
                String query="insert into signup values('"+form+"','"+name+"','"+fname+"','"+dob+"','"+gender+"','"+email+"','"+marital+"','"+add+"','"+city+"','"+state+"','"+pin+"')";
                c.s.executeUpdate(query);

                setVisible(false);
                new signuptwo(form).setVisible(true);
            }


        } catch (Exception e1){
            System.out.println(e1);
        }
    }
    public static void main(String a[]){
        new signupone();
    }
}


