import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Image;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;

public class PinChange extends JFrame implements ActionListener {
    JPasswordField pin;
    JPasswordField repin;
    JButton change;
    JButton back;
    JLabel text;
    JLabel pintext;
    JLabel repintext;
    String pinnumber;

    PinChange(String pinnumber) {
        this.pinnumber = pinnumber;
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/atm.jpg"));
        Image i2 = i1.getImage().getScaledInstance(900, 900, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 900, 900);
        this.add(image);
        this.text = new JLabel("CHANGE YOUR PIN");
        this.text.setFont(new Font("System",Font.BOLD,16));
        this.text.setForeground(Color.WHITE);
        this.pintext = new JLabel("New PIN:");
        this.pintext .setFont(new Font("System",Font.BOLD,16));
        this.pintext.setForeground(Color.WHITE);
        this.repintext = new JLabel("Re-Enter New PIN:");
        this.repintext.setFont(new Font("System", 1, 16));
        this.repintext.setForeground(Color.WHITE);
        this.pin = new JPasswordField();
        this.pin.setFont(new Font("Raleway", 1, 25));
        this.repin = new JPasswordField();
        this.repin.setFont(new Font("Raleway", 1, 25));
        this.change = new JButton("CHANGE");
        this.back = new JButton("BACK");
        this.change.addActionListener(this);
        this.back.addActionListener(this);
        this.setLayout((LayoutManager)null);
        this.text.setBounds(250,280,500,35);
        image.add(this.text);
        this.pintext .setBounds(165,320,180,25);
        image.add(this.pintext);
        this.repintext.setBounds(165,360,200,25);
        image.add(this.repintext);
        this.pin.setBounds(330,320,180,25);
        image.add(this.pin);
        this.repin.setBounds(330,360,180,25);
        image.add(this.repin);
        this.change.setBounds(370,485,150,30);
        image.add(this.change);
        this.back.setBounds(150,485,150,30);
        image.add(this.back);
        this.setSize(900, 900);
        this.setLocation(300, 0);
        this.setUndecorated(true);
        this.setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        try {
            String npin = this.pin.getText();
            String rpin = this.repin.getText();
            if (!npin.equals(rpin)) {
                JOptionPane.showMessageDialog((Component)null, "Entered PIN does not match");
                return;
            }

            if (ae.getSource() == this.change) {
                if (this.pin.getText().equals("")) {
                    JOptionPane.showMessageDialog((Component)null, "Enter New PIN");
                }

                if (this.repin.getText().equals("")) {
                    JOptionPane.showMessageDialog((Component)null, "Re-Enter new PIN");
                }

                conn c1 = new conn();
                String q1 = "update bank set pin = '" + rpin + "' where pin = '" + this.pinnumber + "' ";
                String q2 = "update login set pin = '" + rpin + "' where pin = '" + this.pinnumber + "' ";
                String q3 = "update signupthree set pin = '" + rpin + "' where pin = '" + this.pinnumber + "' ";
                c1.s.executeUpdate(q1);
                c1.s.executeUpdate(q2);
                c1.s.executeUpdate(q3);
                JOptionPane.showMessageDialog((Component)null, "PIN changed successfully");
                this.setVisible(false);
                (new Transactions(rpin)).setVisible(true);
            } else if (ae.getSource() == this.back) {
                (new Transactions(this.pinnumber)).setVisible(true);
                this.setVisible(false);
            }
        } catch (Exception var8) {
            var8.printStackTrace();
        }

    }

    public static void main(String[] args) {
        (new PinChange("")).setVisible(true);
    }
}