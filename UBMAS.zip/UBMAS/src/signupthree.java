import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class signupthree extends JFrame implements ActionListener {
    JRadioButton saving,fixed,current,recur;
    JCheckBox j1,j2,j3,j4,j5,j6,j7;
    JButton submit,cancel;
    String form;
    signupthree(String form){
        this.form=form;
        setLayout(null);
        JLabel l1= new JLabel("Page 3: Account Details");
        l1.setFont(new Font("Raleway", Font.BOLD,22));
        l1.setBounds(280,40,400,40);
        add(l1);

        JLabel type=new JLabel("Account Type");
        type.setFont(new Font("Raleway",Font.BOLD,22));
        type.setBounds(100,140,200,30);
        add(type);

        saving=new JRadioButton("Savings Account");
        saving.setFont(new Font("Raleway",Font.BOLD,16));
        saving.setBackground(Color.WHITE);
        saving.setBounds(100,180,250,20);
        add(saving);

        fixed=new JRadioButton("Fixed Deposit Account");
        fixed.setFont(new Font("Raleway",Font.BOLD,16));
        fixed.setBackground(Color.WHITE);
        fixed.setBounds(350,180,250,20);
        add(fixed);

        current=new JRadioButton("Current Account");
        current.setFont(new Font("Raleway",Font.BOLD,16));
        current.setBackground(Color.WHITE);
        current.setBounds(100,220,250,20);
        add(current);

        recur=new JRadioButton("Recurring Account");
        recur.setFont(new Font("Raleway",Font.BOLD,16));
        recur.setBackground(Color.WHITE);
        recur.setBounds(350,220,250,20);
        add(recur);

        ButtonGroup groupaccount = new ButtonGroup();
        groupaccount.add(saving);
        groupaccount.add(fixed);
        groupaccount.add(current);
        groupaccount.add(recur);

        JLabel card=new JLabel("Card Number");
        card.setFont(new Font("Raleway",Font.BOLD,22));
        card.setBounds(100,300,200,30);
        add(card);

        JLabel number=new JLabel("XXXX-XXXX-XXXX-5721");
        number.setFont(new Font("Raleway",Font.BOLD,22));
        number.setBounds(330,300,300,30);
        add(number);

        JLabel cardDetail=new JLabel("Your 16 Digit Card Number");
        cardDetail.setFont(new Font("Raleway",Font.BOLD,12));
        cardDetail.setBounds(100,330,300,15);
        add(cardDetail);

        JLabel pin=new JLabel("PIN:");
        pin.setFont(new Font("Raleway",Font.BOLD,22));
        pin.setBounds(100,370,200,30);
        add(pin);

        JLabel pnumber=new JLabel("XXXX");
        pnumber.setFont(new Font("Raleway",Font.BOLD,22));
        pnumber.setBounds(330,370,300,30);
        add(pnumber);

        JLabel pinDetail=new JLabel("Your 4 Digit PIN Number");
        pinDetail.setFont(new Font("Raleway",Font.BOLD,12));
        pinDetail.setBounds(100,400,300,15);
        add(pinDetail);

        JLabel services=new JLabel("Services Required:");
        services.setFont(new Font("Raleway",Font.BOLD,22));
        services.setBounds(100,450,250,30);
        add(services);

        j1= new JCheckBox("ATM CARD");
        j1.setBackground(Color.WHITE);
        j1.setFont(new Font("Raleway",Font.BOLD,16));
        j1.setBounds(100,500,200,30);
        add(j1);

        j2= new JCheckBox("Internet Banking");
        j2.setBackground(Color.WHITE);
        j2.setFont(new Font("Raleway",Font.BOLD,16));
        j2.setBounds(350,500,200,30);
        add(j2);

        j3= new JCheckBox("Mobile Banking");
        j3.setBackground(Color.WHITE);
        j3.setFont(new Font("Raleway",Font.BOLD,16));
        j3.setBounds(100,550,200,30);
        add(j3);

        j4= new JCheckBox("EMAIL & SMS ALERTS");
        j4.setBackground(Color.WHITE);
        j4.setFont(new Font("Raleway",Font.BOLD,16));
        j4.setBounds(350,550,200,30);
        add(j4);

        j5= new JCheckBox("Cheque Book");
        j5.setBackground(Color.WHITE);
        j5.setFont(new Font("Raleway",Font.BOLD,16));
        j5.setBounds(100,600,200,30);
        add(j5);

        j6= new JCheckBox("E-Statement");
        j6.setBackground(Color.WHITE);
        j6.setFont(new Font("Raleway",Font.BOLD,16));
        j6.setBounds(350,600,200,30);
        add(j6);

        j7= new JCheckBox("I Hereby declare that the above entered details are correct to the best of my knowledge.");
        j7.setBackground(Color.WHITE);
        j7.setFont(new Font("Raleway",Font.BOLD,12));
        j7.setBounds(100,680,600,30);
        add(j7);

        cancel=new JButton("Cancel");
        cancel.setBackground(Color.WHITE);
        cancel.setForeground(Color.BLACK);
        cancel.setFont(new Font("Raleway",Font.BOLD,14));
        cancel.setBounds(250,720,100,30);
        cancel.addActionListener(this);
        add(cancel);

        submit=new JButton("Submit");
        submit.setBackground(Color.WHITE);
        submit.setForeground(Color.BLACK);
        submit.setFont(new Font("Raleway",Font.BOLD,14));
        submit.setBounds(420,720,100,30);
        submit.addActionListener(this);
        add(submit);

        getContentPane().setBackground(Color.WHITE);



        setSize(850,820);
        setLocation(350,0);
        setVisible(true);
    }
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == submit) {
            String accountType=null;
            if(saving.isSelected()){
                accountType="Savings Account";
            } else if(fixed.isSelected()){
                accountType="Fixed Deposit Account";
            } else if(current.isSelected()){
                accountType="Current Account";
            } else if(recur.isSelected()){
                accountType="Reccuring Deposit Account";
            }

            Random random= new Random();
            String cardnumber=""+Math.abs((random.nextLong()%90000000L)+4355789100000000L);

            String pinnumber=""+Math.abs((random.nextLong()%9000L)+1000L);

            String facility="";
            if(j1.isSelected()){
                facility=facility+" ATM Card";
            }else if(j2.isSelected()){
                facility=facility+"Internet Banking";
            }else if(j3.isSelected()){
                facility=facility+"Mobile Banking";
            }else if(j4.isSelected()){
                facility=facility+"EMAIL & SMS Alerts";
            }else if(j5.isSelected()){
                facility=facility+"Cheque Book";
            }else if(j6.isSelected()){
                facility=facility+"E-Statement";
            }

            try{
                if(accountType.equals("")){
                    JOptionPane.showMessageDialog(null,"Account Type is Required");
                }else {
                    conn conn=new conn();
                    String query1="insert into signupthree values('"+form+"','"+accountType+"','"+cardnumber+"','"+pinnumber+"','"+facility+"' )";
                    String query2="insert into login values('"+form+"','"+cardnumber+"','"+pinnumber+"')";

                    conn.s.executeUpdate(query1);
                    conn.s.executeUpdate(query2);

                    JOptionPane.showMessageDialog(null,"Card Number" + cardnumber+ "\nPIN: "+ pinnumber);
                }
            } catch (Exception e){
                System.out.println(e);
            }
        } else if (ae.getSource() == cancel) {

        }
    }
        public static void main(String args[]){
        new signupthree("");
    }
}




